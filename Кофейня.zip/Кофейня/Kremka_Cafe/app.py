from __future__ import annotations

import os
import re
import sqlite3
from datetime import datetime, timedelta
from functools import wraps
from pathlib import Path
from typing import Any

from flask import (
    Flask, abort, flash, g, redirect, render_template, request, session,
    url_for, jsonify,
)
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename
import uuid

BASE_DIR = Path(__file__).resolve().parent
DATABASE = BASE_DIR / "cafe.db"
UPLOAD_DIR = BASE_DIR / "static" / "images"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

app = Flask(__name__)
app.config.update(
    SECRET_KEY=os.environ.get("SECRET_KEY", "dev-secret-change-before-deploy-2026"),
    DATABASE=str(DATABASE),
    MAX_CONTENT_LENGTH=8 * 1024 * 1024,
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
)

SCHEMA = """
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE COLLATE NOCASE,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'client' CHECK(role IN ('client','admin')),
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS categories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE
);
CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    category_id INTEGER NOT NULL REFERENCES categories(id),
    name TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    price REAL NOT NULL CHECK(price >= 0),
    image_url TEXT NOT NULL DEFAULT '',
    stock INTEGER NOT NULL DEFAULT 0 CHECK(stock >= 0),
    is_active INTEGER NOT NULL DEFAULT 1 CHECK(is_active IN (0,1)),
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id),
    customer_name TEXT NOT NULL,
    phone TEXT NOT NULL,
    delivery_method TEXT NOT NULL CHECK(delivery_method IN ('pickup','delivery')),
    address TEXT NOT NULL DEFAULT '',
    comment TEXT NOT NULL DEFAULT '',
    sticker TEXT NOT NULL DEFAULT '',
    total REAL NOT NULL CHECK(total >= 0),
    status TEXT NOT NULL DEFAULT 'new' CHECK(status IN ('new','preparing','ready','completed','cancelled')),
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS order_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    product_id INTEGER REFERENCES products(id) ON DELETE SET NULL,
    product_name TEXT NOT NULL,
    quantity INTEGER NOT NULL CHECK(quantity > 0),
    unit_price REAL NOT NULL CHECK(unit_price >= 0),
    line_total REAL NOT NULL CHECK(line_total >= 0)
);
CREATE TABLE IF NOT EXISTS blog_posts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    slug TEXT NOT NULL UNIQUE,
    excerpt TEXT NOT NULL DEFAULT '',
    content TEXT NOT NULL,
    image_url TEXT NOT NULL DEFAULT '',
    is_published INTEGER NOT NULL DEFAULT 1 CHECK(is_published IN (0,1)),
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category_id);
CREATE INDEX IF NOT EXISTS idx_orders_user ON orders(user_id);
CREATE INDEX IF NOT EXISTS idx_orders_created ON orders(created_at);
CREATE INDEX IF NOT EXISTS idx_order_items_order ON order_items(order_id);
"""

PRODUCT_SEED = [
    (1, "Эспрессо", "Насыщенный кофе с плотной крема-пенкой и шоколадным послевкусием.", 150, "https://images.unsplash.com/photo-1510707577719-ae7c14805e3a?auto=format&fit=crop&w=900&q=85", 80),
    (1, "Американо", "Эспрессо, дополненный горячей водой. Чистый вкус и мягкая крепость.", 180, "https://images.unsplash.com/photo-1551030173-122aabc4489c?auto=format&fit=crop&w=900&q=85", 70),
    (1, "Капучино", "Двойной эспрессо и нежная молочная пена.", 230, "https://images.unsplash.com/photo-1572442388796-11668a67e53d?auto=format&fit=crop&w=900&q=85", 65),
    (1, "Латте", "Мягкий кофейный напиток с большим количеством молока.", 250, "https://images.unsplash.com/photo-1461023058943-07fcbe16d735?auto=format&fit=crop&w=900&q=85", 60),
    (1, "Флэт уайт", "Двойной ристретто и тонкая шелковистая молочная текстура.", 260, "https://images.unsplash.com/photo-1534778101976-62847782c213?auto=format&fit=crop&w=900&q=85", 50),
    (1, "Раф ванильный", "Кофе со сливками и натуральной ванилью.", 290, "https://images.unsplash.com/photo-1570968915860-54d5c301fa9f?auto=format&fit=crop&w=900&q=85", 45),
    (2, "Круассан", "Слоёная выпечка с хрустящей корочкой и нежной серединой.", 170, "https://images.unsplash.com/photo-1555507036-ab1f4038808a?auto=format&fit=crop&w=900&q=85", 35),
    (2, "Чизкейк", "Сливочный десерт на песочной основе.", 320, "https://images.unsplash.com/photo-1533134242443-d4fd215305ad?auto=format&fit=crop&w=900&q=85", 18),
    (2, "Булочка с корицей", "Мягкая сдобная булочка с корицей и глазурью.", 210, "https://images.unsplash.com/photo-1509365465985-25d11c17e812?auto=format&fit=crop&w=900&q=85", 24),
    (2, "Брауни", "Шоколадный пирог с насыщенным вкусом какао.", 240, "https://images.unsplash.com/photo-1606313564200-e75d5e30476c?auto=format&fit=crop&w=900&q=85", 20),
    (3, "Сэндвич с курицей", "Тостовый хлеб, курица, салат и фирменный соус.", 290, "https://images.unsplash.com/photo-1528735602780-2552fd46c7af?auto=format&fit=crop&w=900&q=85", 22),
    (3, "Тост с авокадо", "Хрустящий тост, авокадо и лёгкая лимонная заправка.", 330, "https://images.unsplash.com/photo-1525351484163-7529414344d8?auto=format&fit=crop&w=900&q=85", 16),
]

POST_SEED = [
    ("Как выбрать свой кофе", "kak-vybrat-kofe", "Небольшой гид по сортам, обжарке и вкусовым оттенкам.", "Начните с того, какие вкусы вам нравятся. Для яркой кислинки выбирайте более светлую обжарку, для плотного шоколадного профиля — среднюю или тёмную. Не бойтесь просить бариста подсказать напиток под ваше настроение.", "https://images.unsplash.com/photo-1442512595331-e89e73853f31?auto=format&fit=crop&w=1000&q=85"),
    ("Почему важна свежая обжарка", "svежая-obжарка", "Разбираемся, как свежесть зерна влияет на чашку кофе.", "После обжарки кофе постепенно меняется: аромат становится мягче, а вкусовой профиль раскрывается иначе. Для яркой и сбалансированной чашки важно правильно хранить зерно — в сухом, прохладном месте и в герметичной упаковке.", "https://images.unsplash.com/photo-1559525839-b184a4d698c7?auto=format&fit=crop&w=1000&q=85"),
    ("Идеальная пара: кофе и выпечка", "kofe-i-vypechka", "Какие десерты лучше всего сочетаются с любимыми напитками.", "Капучино хорошо сочетается с круассаном, а насыщенный эспрессо — с шоколадным брауни. К более лёгкому латте можно выбрать чизкейк или нежную булочку с корицей. Главное правило — выбирайте сочетание, которое нравится именно вам.", "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=1000&q=85"),
]


def get_db() -> sqlite3.Connection:
    if "db" not in g:
        g.db = sqlite3.connect(app.config["DATABASE"])
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(_error: BaseException | None = None) -> None:
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db() -> None:
    db = sqlite3.connect(app.config["DATABASE"])
    db.row_factory = sqlite3.Row
    db.executescript(SCHEMA)
    if db.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0:
        now = datetime.now().isoformat(timespec="seconds")
        db.execute("INSERT INTO users(name,email,password_hash,role,created_at) VALUES(?,?,?,?,?)",
                   ("Администратор", "admin@mail.ru", generate_password_hash("admin123"), "admin", now))
        db.execute("INSERT INTO users(name,email,password_hash,role,created_at) VALUES(?,?,?,?,?)",
                   ("Клиент", "client@mail.ru", generate_password_hash("client123"), "client", now))
    if db.execute("SELECT COUNT(*) FROM categories").fetchone()[0] == 0:
        db.executemany("INSERT INTO categories(name) VALUES(?)", [("Кофе",), ("Десерты и выпечка",), ("Перекусы",)])
    if db.execute("SELECT COUNT(*) FROM products").fetchone()[0] == 0:
        now = datetime.now().isoformat(timespec="seconds")
        db.executemany("""INSERT INTO products(category_id,name,description,price,image_url,stock,created_at)
                          VALUES(?,?,?,?,?,?,?)""", [(*item, now) for item in PRODUCT_SEED])
    if db.execute("SELECT COUNT(*) FROM blog_posts").fetchone()[0] == 0:
        now = datetime.now().isoformat(timespec="seconds")
        db.executemany("""INSERT INTO blog_posts(title,slug,excerpt,content,image_url,is_published,created_at)
                          VALUES(?,?,?,?,?,1,?)""", [(*item, now) for item in POST_SEED])
    db.commit()
    db.close()


@app.before_request
def load_user() -> None:
    user_id = session.get("user_id")
    g.user = get_db().execute("SELECT id,name,email,role FROM users WHERE id=?", (user_id,)).fetchone() if user_id else None


def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not g.user or g.user["role"] != "admin":
            flash("Для доступа к этому разделу войдите как администратор.", "warning")
            return redirect(url_for("login", next=request.path))
        return view(*args, **kwargs)
    return wrapped


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not g.user:
            flash("Сначала войдите в аккаунт.", "warning")
            return redirect(url_for("login", next=request.path))
        return view(*args, **kwargs)
    return wrapped


def cart_data() -> tuple[list[dict[str, Any]], float]:
    cart = session.get("cart", {})
    if not cart:
        return [], 0.0
    ids = [int(k) for k in cart.keys() if str(k).isdigit()]
    if not ids:
        return [], 0.0
    placeholders = ",".join("?" for _ in ids)
    rows = get_db().execute(f"SELECT * FROM products WHERE id IN ({placeholders}) AND is_active=1", ids).fetchall()
    items: list[dict[str, Any]] = []
    total = 0.0
    for product in rows:
        qty = max(1, int(cart.get(str(product["id"]), 1)))
        subtotal = product["price"] * qty
        items.append({"product": product, "quantity": qty, "subtotal": subtotal})
        total += subtotal
    return items, total


@app.context_processor
def inject_globals():
    cart = session.get("cart", {})
    return {"current_user": getattr(g, "user", None), "cart_count": sum(int(v) for v in cart.values()) if cart else 0, "now_year": datetime.now().year, "now_date": datetime.now().strftime("%d.%m.%Y")}


def safe_next(value: str | None) -> str:
    if value and value.startswith("/") and not value.startswith("//"):
        return value
    return url_for("index")


def slugify(value: str) -> str:
    value = value.strip().lower()
    value = re.sub(r"[^a-zа-яё0-9]+", "-", value, flags=re.IGNORECASE).strip("-")
    return value or f"post-{int(datetime.now().timestamp())}"


@app.route("/")
def index():
    db = get_db()
    categories = db.execute("SELECT * FROM categories ORDER BY id").fetchall()
    products = db.execute("""SELECT p.*, c.name AS category_name FROM products p
                              JOIN categories c ON c.id=p.category_id
                              WHERE p.is_active=1 ORDER BY p.id LIMIT 8""").fetchall()
    posts = db.execute("SELECT * FROM blog_posts WHERE is_published=1 ORDER BY created_at DESC LIMIT 3").fetchall()
    return render_template("index.html", categories=categories, products=products, posts=posts)


@app.route("/menu")
def menu():
    db = get_db()
    category_id = request.args.get("category", type=int)
    query = request.args.get("q", "").strip()
    sql = "SELECT p.*, c.name AS category_name FROM products p JOIN categories c ON c.id=p.category_id WHERE p.is_active=1"
    params: list[Any] = []
    if category_id:
        sql += " AND p.category_id=?"
        params.append(category_id)
    if query:
        sql += " AND (p.name LIKE ? OR p.description LIKE ?)"
        params.extend([f"%{query}%", f"%{query}%"])
    sql += " ORDER BY p.category_id,p.name"
    products = db.execute(sql, params).fetchall()
    categories = db.execute("SELECT * FROM categories ORDER BY id").fetchall()
    return render_template("menu.html", products=products, categories=categories, selected=category_id, query=query)


@app.route("/product/<int:product_id>")
def product_detail(product_id: int):
    product = get_db().execute("""SELECT p.*,c.name AS category_name FROM products p
                                  JOIN categories c ON c.id=p.category_id WHERE p.id=? AND p.is_active=1""", (product_id,)).fetchone()
    if not product:
        abort(404)
    return render_template("product.html", product=product)


@app.route("/register", methods=["GET", "POST"])
def register():
    if g.user:
        return redirect(url_for("index"))
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        if len(name) < 2 or len(name) > 80:
            flash("Имя должно содержать от 2 до 80 символов.", "danger")
        elif not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", email):
            flash("Введите корректный email.", "danger")
        elif len(password) < 6:
            flash("Пароль должен содержать минимум 6 символов.", "danger")
        else:
            try:
                cur = get_db().execute("INSERT INTO users(name,email,password_hash,role,created_at) VALUES(?,?,?,?,?)",
                                       (name, email, generate_password_hash(password), "client", datetime.now().isoformat(timespec="seconds")))
                get_db().commit()
                session.clear()
                session["user_id"] = cur.lastrowid
                flash("Аккаунт создан. Добро пожаловать!", "success")
                return redirect(url_for("index"))
            except sqlite3.IntegrityError:
                flash("Пользователь с таким email уже зарегистрирован.", "danger")
    return render_template("auth.html", mode="register")


@app.route("/login", methods=["GET", "POST"])
def login():
    if g.user:
        return redirect(url_for("index"))
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        user = get_db().execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"] = user["id"]
            flash(f"Рады видеть, {user['name']}!", "success")
            return redirect(safe_next(request.args.get("next") or request.form.get("next")))
        flash("Неверный email или пароль.", "danger")
    return render_template("auth.html", mode="login", next_url=safe_next(request.args.get("next")))


@app.route("/logout", methods=["POST"])
def logout():
    session.clear()
    flash("Вы вышли из аккаунта.", "info")
    return redirect(url_for("index"))


@app.route("/cart")
def cart():
    items, total = cart_data()
    return render_template("cart.html", items=items, total=total)


@app.route("/cart/add/<int:product_id>", methods=["POST"])
def cart_add(product_id: int):
    product = get_db().execute("SELECT id,stock,is_active,name FROM products WHERE id=?", (product_id,)).fetchone()
    if not product or not product["is_active"]:
        abort(404)
    qty = max(1, min(20, request.form.get("quantity", 1, type=int)))
    cart = session.get("cart", {})
    current = int(cart.get(str(product_id), 0))
    if current + qty > product["stock"]:
        message = f"Недостаточно товара «{product['name']}» на складе."
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return jsonify(ok=False, message=message, cart_count=sum(int(v) for v in cart.values())), 400
        flash(message, "warning")
    else:
        cart[str(product_id)] = current + qty
        session["cart"] = cart
        message = f"«{product['name']}» добавлен в корзину."
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return jsonify(ok=True, message=message, cart_count=sum(int(v) for v in cart.values()))
        flash(message, "success")
    return redirect(request.referrer or url_for("menu"))


@app.route("/cart/update", methods=["POST"])
def cart_update():
    cart = session.get("cart", {})
    for key, value in request.form.items():
        if key.startswith("qty_"):
            product_id = key[4:]
            if product_id not in cart:
                continue
            try:
                qty = int(value)
            except ValueError:
                qty = 1
            if qty <= 0:
                cart.pop(product_id, None)
            else:
                stock = get_db().execute("SELECT stock FROM products WHERE id=?", (int(product_id),)).fetchone()
                cart[product_id] = min(qty, stock["stock"] if stock else qty)
    session["cart"] = cart
    flash("Корзина обновлена.", "success")
    return redirect(url_for("cart"))


@app.route("/cart/remove/<int:product_id>", methods=["POST"])
def cart_remove(product_id: int):
    cart = session.get("cart", {})
    cart.pop(str(product_id), None)
    session["cart"] = cart
    return redirect(url_for("cart"))


ALLOWED_STICKERS = {"Срочно", "Подарок", "Без сахара", "Побольше пенки", "С собой"}


@app.route("/checkout", methods=["GET", "POST"])
@login_required
def checkout():
    items, total = cart_data()
    if not items:
        flash("Корзина пока пуста.", "warning")
        return redirect(url_for("menu"))
    if request.method == "POST":
        customer_name = request.form.get("customer_name", "").strip()
        phone = request.form.get("phone", "").strip()
        delivery_method = request.form.get("delivery_method", "pickup")
        address = request.form.get("address", "").strip()
        comment = request.form.get("comment", "").strip()
        sticker = request.form.get("sticker", "").strip()
        if len(customer_name) < 2 or len(phone) < 7:
            flash("Укажите имя и корректный телефон для связи.", "danger")
        elif delivery_method not in {"pickup", "delivery"}:
            flash("Выберите способ получения заказа.", "danger")
        elif delivery_method == "delivery" and len(address) < 5:
            flash("Укажите адрес доставки.", "danger")
        elif sticker and sticker not in ALLOWED_STICKERS:
            flash("Выбран неизвестный стикер.", "danger")
        else:
            db = get_db()
            try:
                db.execute("BEGIN IMMEDIATE")
                fresh_items, fresh_total = cart_data()
                for item in fresh_items:
                    if item["quantity"] > item["product"]["stock"]:
                        raise ValueError(f"Недостаточно товара «{item['product']['name']}» на складе.")
                cur = db.execute("""INSERT INTO orders(user_id,customer_name,phone,delivery_method,address,comment,sticker,total,status,created_at)
                                    VALUES(?,?,?,?,?,?,?,?,?,?)""",
                                 (g.user["id"], customer_name, phone, delivery_method, address, comment, sticker,
                                  fresh_total, "new", datetime.now().isoformat(timespec="seconds")))
                order_id = cur.lastrowid
                for item in fresh_items:
                    p = item["product"]
                    qty = item["quantity"]
                    db.execute("INSERT INTO order_items(order_id,product_id,product_name,quantity,unit_price,line_total) VALUES(?,?,?,?,?,?)",
                               (order_id, p["id"], p["name"], qty, p["price"], p["price"] * qty))
                    db.execute("UPDATE products SET stock=stock-? WHERE id=?", (qty, p["id"]))
                db.commit()
                session["cart"] = {}
                return redirect(url_for("receipt", order_id=order_id))
            except (sqlite3.Error, ValueError) as exc:
                db.rollback()
                flash(str(exc) if isinstance(exc, ValueError) else "Не удалось оформить заказ. Попробуйте ещё раз.", "danger")
    return render_template("checkout.html", items=items, total=total, stickers=sorted(ALLOWED_STICKERS))


@app.route("/orders")
@login_required
def my_orders():
    orders = get_db().execute("SELECT * FROM orders WHERE user_id=? ORDER BY id DESC", (g.user["id"],)).fetchall()
    return render_template("orders.html", orders=orders)


@app.route("/receipt/<int:order_id>")
@login_required
def receipt(order_id: int):
    db = get_db()
    order = db.execute("SELECT o.*,u.email FROM orders o JOIN users u ON u.id=o.user_id WHERE o.id=?", (order_id,)).fetchone()
    if not order or (order["user_id"] != g.user["id"] and g.user["role"] != "admin"):
        abort(404)
    items = db.execute("SELECT * FROM order_items WHERE order_id=?", (order_id,)).fetchall()
    return render_template("receipt.html", order=order, items=items)


@app.route("/blog")
def blog():
    posts = get_db().execute("SELECT * FROM blog_posts WHERE is_published=1 ORDER BY created_at DESC").fetchall()
    return render_template("blog.html", posts=posts)


@app.route("/blog/<slug>")
def blog_post(slug: str):
    post = get_db().execute("SELECT * FROM blog_posts WHERE slug=? AND is_published=1", (slug,)).fetchone()
    if not post:
        abort(404)
    return render_template("blog_post.html", post=post)


@app.route("/admin")
@admin_required
def admin_dashboard():
    db = get_db()
    today = datetime.now().date().isoformat()
    stats = {
        "orders": db.execute("SELECT COUNT(*) FROM orders").fetchone()[0],
        "revenue": db.execute("SELECT COALESCE(SUM(total),0) FROM orders WHERE status!='cancelled'").fetchone()[0],
        "users": db.execute("SELECT COUNT(*) FROM users WHERE role='client'").fetchone()[0],
        "products": db.execute("SELECT COUNT(*) FROM products WHERE is_active=1").fetchone()[0],
        "today": db.execute("SELECT COUNT(*) FROM orders WHERE date(created_at)=?", (today,)).fetchone()[0],
    }
    recent = db.execute("SELECT o.*,u.name AS user_name FROM orders o JOIN users u ON u.id=o.user_id ORDER BY o.id DESC LIMIT 6").fetchall()
    return render_template("admin/dashboard.html", stats=stats, recent=recent)


def save_product_image(uploaded_file) -> str:
    """Save an uploaded product image and return its public static URL."""
    if not uploaded_file or not uploaded_file.filename:
        return ""
    ext = Path(secure_filename(uploaded_file.filename)).suffix.lower()
    if ext not in {".jpg", ".jpeg", ".png", ".webp", ".gif"}:
        raise ValueError("Поддерживаются изображения JPG, PNG, WEBP и GIF.")
    filename = f"product_{uuid.uuid4().hex}{ext}"
    uploaded_file.save(UPLOAD_DIR / filename)
    return f"/static/images/{filename}"


@app.route("/admin/products", methods=["GET", "POST"])
@admin_required
def admin_products():
    db = get_db()
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        category_id = request.form.get("category_id", type=int)
        description = request.form.get("description", "").strip()
        image_url = request.form.get("image_url", "").strip()
        try:
            uploaded_image = save_product_image(request.files.get("image_file"))
            if uploaded_image:
                image_url = uploaded_image
        except ValueError as exc:
            flash(str(exc), "danger")
            image_url = "__INVALID_UPLOAD__"
        price = request.form.get("price", type=float)
        stock = request.form.get("stock", type=int)
        if image_url == "__INVALID_UPLOAD__":
            pass
        elif len(name) < 2 or not category_id or price is None or price < 0 or stock is None or stock < 0:
            flash("Проверьте название, категорию, цену и остаток товара.", "danger")
        else:
            db.execute("INSERT INTO products(category_id,name,description,price,image_url,stock,created_at) VALUES(?,?,?,?,?,?,?)",
                       (category_id, name, description, price, image_url, stock, datetime.now().isoformat(timespec="seconds")))
            db.commit()
            flash("Товар добавлен в каталог.", "success")
            return redirect(url_for("admin_products"))
    products = db.execute("SELECT p.*,c.name AS category_name FROM products p JOIN categories c ON c.id=p.category_id ORDER BY p.id DESC").fetchall()
    categories = db.execute("SELECT * FROM categories ORDER BY id").fetchall()
    return render_template("admin/products.html", products=products, categories=categories)


@app.route("/admin/products/<int:product_id>/update", methods=["POST"])
@admin_required
def admin_product_update(product_id: int):
    db = get_db()
    name = request.form.get("name", "").strip()
    price = request.form.get("price", type=float)
    stock = request.form.get("stock", type=int)
    description = request.form.get("description", "").strip()
    image_url = request.form.get("image_url", "").strip()
    category_id = request.form.get("category_id", type=int)
    active = 1 if request.form.get("is_active") == "on" else 0
    try:
        uploaded_image = save_product_image(request.files.get("image_file"))
        if uploaded_image:
            image_url = uploaded_image
    except ValueError as exc:
        flash(str(exc), "danger")
        return redirect(url_for("admin_products"))
    if len(name) < 2 or price is None or price < 0 or stock is None or stock < 0 or not category_id:
        flash("Некорректные данные товара.", "danger")
    else:
        db.execute("UPDATE products SET name=?,category_id=?,description=?,price=?,image_url=?,stock=?,is_active=? WHERE id=?",
                   (name, category_id, description, price, image_url, stock, active, product_id))
        db.commit()
        flash("Изменения товара сохранены.", "success")
    return redirect(url_for("admin_products"))


@app.route("/admin/products/<int:product_id>/delete", methods=["POST"])
@admin_required
def admin_product_delete(product_id: int):
    db = get_db()
    db.execute("UPDATE products SET is_active=0 WHERE id=?", (product_id,))
    db.commit()
    flash("Товар скрыт из каталога.", "info")
    return redirect(url_for("admin_products"))


@app.route("/admin/orders", methods=["GET", "POST"])
@admin_required
def admin_orders():
    db = get_db()
    if request.method == "POST":
        order_id = request.form.get("order_id", type=int)
        status = request.form.get("status", "")
        allowed = {"new", "preparing", "ready", "completed", "cancelled"}
        if order_id and status in allowed:
            old_order = db.execute("SELECT status FROM orders WHERE id=?", (order_id,)).fetchone()
            if old_order:
                old_status = old_order["status"]
                if status == "cancelled" and old_status != "cancelled":
                    used_items = db.execute("SELECT product_id,quantity FROM order_items WHERE order_id=? AND product_id IS NOT NULL", (order_id,)).fetchall()
                    for item in used_items:
                        db.execute("UPDATE products SET stock=stock+? WHERE id=?", (item["quantity"], item["product_id"]))
                elif old_status == "cancelled" and status != "cancelled":
                    used_items = db.execute("SELECT product_id,quantity FROM order_items WHERE order_id=? AND product_id IS NOT NULL", (order_id,)).fetchall()
                    shortage = False
                    for item in used_items:
                        available = db.execute("SELECT stock FROM products WHERE id=?", (item["product_id"],)).fetchone()
                        if available is None or available["stock"] < item["quantity"]:
                            shortage = True
                            break
                    if shortage:
                        flash("Нельзя вернуть заказ в работу: не хватает товара на складе.", "danger")
                        return redirect(url_for("admin_orders"))
                    for item in used_items:
                        db.execute("UPDATE products SET stock=stock-? WHERE id=?", (item["quantity"], item["product_id"]))
                db.execute("UPDATE orders SET status=? WHERE id=?", (status, order_id))
                db.commit()
                flash("Статус заказа обновлён.", "success")
        return redirect(url_for("admin_orders"))
    orders = db.execute("""SELECT o.*,u.name AS user_name,u.email AS user_email,
                           (SELECT COUNT(*) FROM order_items i WHERE i.order_id=o.id) AS item_count
                           FROM orders o JOIN users u ON u.id=o.user_id ORDER BY o.id DESC""").fetchall()
    return render_template("admin/orders.html", orders=orders)


@app.route("/admin/posts", methods=["GET", "POST"])
@admin_required
def admin_posts():
    db = get_db()
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        excerpt = request.form.get("excerpt", "").strip()
        content = request.form.get("content", "").strip()
        image_url = request.form.get("image_url", "").strip()
        if len(title) < 3 or len(content) < 10:
            flash("Название должно быть не короче 3 символов, текст — не короче 10.", "danger")
        else:
            base_slug = slugify(title)
            slug = base_slug
            suffix = 2
            while db.execute("SELECT 1 FROM blog_posts WHERE slug=?", (slug,)).fetchone():
                slug = f"{base_slug}-{suffix}"
                suffix += 1
            db.execute("INSERT INTO blog_posts(title,slug,excerpt,content,image_url,is_published,created_at) VALUES(?,?,?,?,?,1,?)",
                       (title, slug, excerpt, content, image_url, datetime.now().isoformat(timespec="seconds")))
            db.commit()
            flash("Статья опубликована.", "success")
            return redirect(url_for("admin_posts"))
    posts = db.execute("SELECT * FROM blog_posts ORDER BY created_at DESC").fetchall()
    return render_template("admin/posts.html", posts=posts)


@app.route("/admin/posts/<int:post_id>/update", methods=["POST"])
@admin_required
def admin_post_update(post_id: int):
    title = request.form.get("title", "").strip()
    excerpt = request.form.get("excerpt", "").strip()
    content = request.form.get("content", "").strip()
    image_url = request.form.get("image_url", "").strip()
    if len(title) < 3 or len(content) < 10:
        flash("Проверьте заголовок и текст статьи.", "danger")
    else:
        get_db().execute("UPDATE blog_posts SET title=?,excerpt=?,content=?,image_url=? WHERE id=?",
                         (title, excerpt, content, image_url, post_id))
        get_db().commit()
        flash("Статья обновлена.", "success")
    return redirect(url_for("admin_posts"))


@app.route("/admin/posts/<int:post_id>/toggle", methods=["POST"])
@admin_required
def admin_post_toggle(post_id: int):
    db = get_db()
    db.execute("UPDATE blog_posts SET is_published=CASE is_published WHEN 1 THEN 0 ELSE 1 END WHERE id=?", (post_id,))
    db.commit()
    flash("Публикация обновлена.", "success")
    return redirect(url_for("admin_posts"))


@app.route("/admin/stats")
@admin_required
def admin_stats():
    db = get_db()
    days = []
    for i in range(6, -1, -1):
        day = (datetime.now().date() - timedelta(days=i))
        value = db.execute("SELECT COALESCE(SUM(total),0) FROM orders WHERE date(created_at)=? AND status!='cancelled'", (day.isoformat(),)).fetchone()[0]
        days.append({"label": day.strftime("%d.%m"), "value": float(value)})
    max_value = max([d["value"] for d in days] + [1])
    for d in days:
        d["height"] = max(4, int(d["value"] / max_value * 150))
    categories = db.execute("""SELECT c.name,COALESCE(SUM(i.line_total),0) AS revenue
                               FROM categories c JOIN products p ON p.category_id=c.id
                               JOIN order_items i ON i.product_id=p.id JOIN orders o ON o.id=i.order_id
                               WHERE o.status!='cancelled' GROUP BY c.id ORDER BY revenue DESC""").fetchall()
    top_products = db.execute("""SELECT product_name,SUM(quantity) AS quantity,SUM(line_total) AS revenue
                                 FROM order_items i JOIN orders o ON o.id=i.order_id
                                 WHERE o.status!='cancelled' GROUP BY product_name ORDER BY quantity DESC LIMIT 5""").fetchall()
    summary = db.execute("SELECT COUNT(*) AS count,COALESCE(SUM(total),0) AS revenue,COALESCE(AVG(total),0) AS average FROM orders WHERE status!='cancelled'").fetchone()
    return render_template("admin/stats.html", days=days, categories=categories, top_products=top_products,
                           summary=summary, max_value=max_value)


@app.errorhandler(403)
def forbidden(_error):
    return render_template("error.html", code=403, message="У вас недостаточно прав для просмотра этой страницы."), 403


@app.errorhandler(404)
def not_found(_error):
    return render_template("error.html", code=404, message="Страница не найдена."), 404


with app.app_context():
    init_db()


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5090, debug=True)
