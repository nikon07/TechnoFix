(() => {
  const navToggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.main-nav');
  if (navToggle && nav) navToggle.addEventListener('click', () => nav.classList.toggle('open'));

  document.querySelectorAll('.flash-close').forEach(button => {
    button.addEventListener('click', () => button.closest('.flash')?.remove());
  });

  // Add products to the cart without reloading the page or losing scroll position.
  document.querySelectorAll('.add-to-cart-form').forEach(form => {
    form.addEventListener('submit', async event => {
      event.preventDefault();
      const button = form.querySelector('button[type="submit"]');
      if (button) button.disabled = true;
      try {
        const response = await fetch(form.action, {
          method: 'POST',
          body: new FormData(form),
          headers: { 'X-Requested-With': 'XMLHttpRequest' }
        });
        const data = await response.json();
        if (data.cart_count !== undefined) {
          const counter = document.querySelector('.cart-link span');
          if (counter) counter.textContent = data.cart_count;
        }
        let notice = document.getElementById('cart-live-notice');
        if (!notice) {
          notice = document.createElement('div');
          notice.id = 'cart-live-notice';
          notice.className = 'flash';
          notice.style.position = 'fixed';
          notice.style.right = '20px';
          notice.style.bottom = '20px';
          notice.style.zIndex = '1000';
          notice.style.maxWidth = 'min(360px, calc(100vw - 40px))';
          notice.style.boxShadow = '0 8px 28px rgba(0,0,0,.14)';
          document.body.appendChild(notice);
        }
        notice.textContent = data.message || 'Не удалось добавить товар.';
        notice.classList.toggle('flash-success', !!data.ok);
        notice.classList.toggle('flash-warning', !data.ok);
        notice.hidden = false;
        window.clearTimeout(notice._hideTimer);
        notice._hideTimer = window.setTimeout(() => { notice.hidden = true; }, 2600);
      } catch (error) {
        // If JavaScript request fails, allow the regular form submission.
        form.submit();
      } finally {
        if (button) button.disabled = false;
      }
    });
  });

  const deliveryRadios = document.querySelectorAll('input[name="delivery_method"]');
  const addressField = document.getElementById('address-field');
  const syncAddress = () => {
    if (!addressField) return;
    const selected = document.querySelector('input[name="delivery_method"]:checked');
    addressField.classList.toggle('visible', selected?.value === 'delivery');
    const input = addressField.querySelector('input');
    if (input) input.required = selected?.value === 'delivery';
  };
  deliveryRadios.forEach(radio => radio.addEventListener('change', syncAddress));
  syncAddress();

  const drop = document.getElementById('sticker-drop');
  const stickerValue = document.getElementById('sticker-value');
  const clearSticker = document.getElementById('clear-sticker');
  const stickerButtons = document.querySelectorAll('.sticker');
  const setSticker = (value) => {
    if (!drop || !stickerValue) return;
    stickerValue.value = value || '';
    const label = drop.querySelector('b');
    const hint = drop.querySelector('small');
    if (value) {
      label.textContent = value;
      hint.textContent = 'Стикер прикреплён к заказу';
      drop.classList.add('has-sticker');
      stickerButtons.forEach(b => b.classList.toggle('selected', b.dataset.sticker === value));
    } else {
      label.textContent = 'Ваше пожелание';
      hint.textContent = 'Перетащите сюда стикер';
      drop.classList.remove('has-sticker');
      stickerButtons.forEach(b => b.classList.remove('selected'));
    }
  };
  stickerButtons.forEach(button => {
    button.addEventListener('dragstart', event => {
      event.dataTransfer.setData('text/plain', button.dataset.sticker);
      button.classList.add('dragging');
    });
    button.addEventListener('dragend', () => button.classList.remove('dragging'));
    button.addEventListener('click', () => setSticker(button.dataset.sticker));
  });
  if (drop) {
    drop.addEventListener('dragover', event => { event.preventDefault(); drop.classList.add('over'); });
    drop.addEventListener('dragleave', () => drop.classList.remove('over'));
    drop.addEventListener('drop', event => {
      event.preventDefault();
      drop.classList.remove('over');
      setSticker(event.dataTransfer.getData('text/plain'));
    });
  }
  if (clearSticker) clearSticker.addEventListener('click', () => setSticker(''));
})();
