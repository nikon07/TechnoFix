@echo off
setlocal
cd /d "%~dp0"
title Kremka Cafe - Install

set "PYTHON_CMD="
where py >nul 2>&1
if not errorlevel 1 (
    py -3 --version >nul 2>&1
    if not errorlevel 1 set "PYTHON_CMD=py -3"
)
if not defined PYTHON_CMD (
    where python >nul 2>&1
    if not errorlevel 1 (
        python --version >nul 2>&1
        if not errorlevel 1 set "PYTHON_CMD=python"
    )
)
if not defined PYTHON_CMD (
    echo ERROR: Python 3 was not found.
    echo Install Python 3.10 or newer from https://www.python.org/downloads/windows/
    echo During installation, enable the option to add Python to PATH.
    pause
    exit /b 1
)

echo Creating virtual environment...
%PYTHON_CMD% -m venv .venv
if errorlevel 1 goto failed

echo Installing required packages...
.venv\Scripts\python.exe -m pip install --upgrade pip
if errorlevel 1 goto failed
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto failed

echo.
echo Installation completed. Start the application with run.bat.
pause
exit /b 0

:failed
echo.
echo ERROR: Installation failed. Check the messages above and your Internet connection.
pause
exit /b 1
