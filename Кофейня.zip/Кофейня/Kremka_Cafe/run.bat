@echo off
setlocal
cd /d "%~dp0"
title Kremka Cafe - Run

if not exist ".venv\Scripts\python.exe" (
    echo ERROR: The virtual environment was not found.
    echo Run install.bat first.
    pause
    exit /b 1
)

echo Starting Kremka Cafe...
.venv\Scripts\python.exe app.py
if errorlevel 1 (
    echo.
    echo The application stopped because of an error. Read the message above.
    pause
)
